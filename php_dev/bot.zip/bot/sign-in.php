<?php
  require_once("../init.php");
  require_once("../function.php");

  if(!isset($_POST) || $_POST['admPassword'] !== "adm08.22") {
    json_encode("password is incorrect or _POST array is empty");
    exit;
  }

  $json = [];
  $errors = [];
  $user = $_POST;
  $rules = [
    'email' => function(){
      if(!validateEmail('email')){
        return "Введите корректный email";
      }
    },
    'password' => function() {
      if (!validateFilled('password')) {
        return "Заполните это поле";
      }
    }
  ];
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($user as $key => $value) {
      if (isset($rules[$key])) {
        $rule = $rules[$key];
        $result = $rule($value);
        if ($result !== null) {
          $errors[$key] = $result;
        }
      }
    }
  }
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($errors)) {
    $safe_email = mysqli_real_escape_string($connection, $_POST['email']);
    $sql_info = "SELECT id, name, url, password FROM users WHERE email = '$safe_email'";
    $res = mysqli_query($connection, $sql_info);
    if (!$res) {
      die("Произошла ошибка!");
    }
    $json = mysqli_fetch_all($res, MYSQLI_ASSOC);
    if (!empty($user_info)){
      $user_password = $user_info[0];
    }
    if (mysqli_num_rows($res) === 0) {
      $errors['email'] = 'Пользователь с таким email не зарегистрирован';
    } else {
      if (password_verify($_POST['password'], $user_password['password'])) {
        print (json_encode($json));
        $errors = array_filter($errors);
        exit;
      } else {
        $json[0] = false;
      }
    }
  }
  $errors = array_filter($errors);
  print (json_encode($json));
  ?>
